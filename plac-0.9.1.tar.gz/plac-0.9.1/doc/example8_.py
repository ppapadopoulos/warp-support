# example8_.py
def main(dsn, command: ("SQL query", 'option', 'q')='select * from table'):
    print('executing %r on %s' % (command, dsn))

if __name__ == '__main__':
    import plac; plac.call(main)
