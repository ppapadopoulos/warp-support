from __future__ import with_statement
from plac_tk import TkMonitor

with TkMonitor('tkmon') as mon:
    mon.run()
