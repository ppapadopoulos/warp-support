typedef struct {
    int x;
} MyStruct;

